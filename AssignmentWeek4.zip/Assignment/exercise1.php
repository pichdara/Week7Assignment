

<!-- The advantage of multiple inheritance is that it allows 
a class to inherit the functionality of more than one base 
class thus allowing for modeling of complex relationships.
The disadvantage of multiple inheritance is that it can lead 
to a lot of confusion when two base classes implement a 
method with the same name. -->



<?php //use class along with Trait

// Class Greet 
class Greet { 
public function sayhello() { 
	echo "Hello"; 
} 
} 

// Trait forGreet 
trait forGreet { 
public function sayfor() { 
	echo " People"; 
} 
} 

class Sample extends Greet { 
use forGreet; 
public function Welcome () { 
	echo "\nWelcome to PHP"; 
} 
} 

$test = new Sample(); 
$test->sayhello(); 
$test->sayfor(); 
$test->Welcome(); 
?> 
