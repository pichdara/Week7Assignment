
<?php



trait PaymentData
{
  public static $eachSales = 0;
  public static $eachTotal = 0;

  function __construct($price, $quantity)
  {
    parent::__construct($price, $quantity);

    self::$eachSales += $this->quantity;
    self::$eachTotal += $this->total;
  }
}

class OnlinePayment
{
  public $price, $quantity, $total;

  function __construct($price, $quantity)
  {
    $this->price = $price;
    $this->quantity = $quantity;

    $this->total = $price * $quantity;
  }
}

class ABA extends OnlinePayment
{
  use PaymentData;
}

class Wing extends OnlinePayment
{
  use PaymentData;
}

class PiPay extends OnlinePayment
{
  use PaymentData;
}

$item1 = new ABA(5, 1);
$item2 = new Wing(3, 2);
$item3 = new ABA(4, 1);
$item4 = new ABA(5, 1);
$item5 = new PiPay(6, 1);
$item6 = new ABA(10, 1);
$item7 = new Wing(15, 1);
$item8 = new Wing(2, 1);


print('1. Number of sales by ABA: ' . ABa::$eachSales . PHP_EOL . PHP_EOL);
print('2. Number of sales by Wing and PiPay: ' . (Wing::$eachSales + PiPay::$eachSales) . PHP_EOL . PHP_EOL);
print('3. Display all sales ordering by biggest total amount: ' . PHP_EOL);


$companies = array_map(fn ($x) => array(
  'name' => $x,
  'total' => $x::$eachTotal,
  'sales' => $x::$eachSales
), ['ABA', 'Wing', 'PiPay']);


$companiesClone = $companies;
usort($companiesClone, fn ($x, $y) => $y['total'] <=> $x['total']);

// Print each company's sales 
foreach ($companiesClone as $key => $val) {
  print($val['name'] . '\'s Sales: ' . $val['sales'] . ' Total: ' . $val['total'] . PHP_EOL);
}
?>